-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28 Nov 2017 pada 05.53
-- Versi Server: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ematch`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dept_schedule`
--

CREATE TABLE `dept_schedule` (
  `DEPT_ID` int(11) NOT NULL,
  `SCH_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dept_schedule`
--

INSERT INTO `dept_schedule` (`DEPT_ID`, `SCH_ID`) VALUES
(1, 19),
(1, 20),
(4, 20);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_reminder`
--

CREATE TABLE `jenis_reminder` (
  `id` int(11) NOT NULL,
  `nama_jenis` varchar(80) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_reminder`
--

INSERT INTO `jenis_reminder` (`id`, `nama_jenis`, `keterangan`) VALUES
(1, 'Sewa Persil', 'Sewa Persil'),
(2, 'Pajak Reklame', 'Pajak Reklame'),
(3, 'Pajak PBB', 'Pajak PBB'),
(4, 'Pangkas Pohon', 'Pangkas Pohon'),
(6, 'BAPP I', 'BAPP Tahap I'),
(7, 'Bina Marga', 'TBD'),
(8, '', ''),
(9, '123', '123'),
(10, '', ''),
(11, '', ''),
(12, '', ''),
(13, '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member_schedule`
--

CREATE TABLE `member_schedule` (
  `SCH_ID` int(11) NOT NULL,
  `KRY_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `member_schedule`
--

INSERT INTO `member_schedule` (`SCH_ID`, `KRY_ID`) VALUES
(19, 70),
(19, 71),
(19, 74),
(19, 80),
(20, 70),
(20, 74),
(20, 80);

-- --------------------------------------------------------

--
-- Struktur dari tabel `reminder`
--

CREATE TABLE `reminder` (
  `id` int(11) NOT NULL,
  `nama_reminder` varchar(255) NOT NULL,
  `jenis_reminder` varchar(20) NOT NULL,
  `info_reminder` varchar(10000) NOT NULL,
  `tanggal_batas` date NOT NULL,
  `email_atasan` varchar(80) NOT NULL,
  `dept` varchar(10) NOT NULL,
  `email3` varchar(5) DEFAULT NULL,
  `email2` varchar(5) DEFAULT NULL,
  `email1` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `reminder`
--

INSERT INTO `reminder` (`id`, `nama_reminder`, `jenis_reminder`, `info_reminder`, `tanggal_batas`, `email_atasan`, `dept`, `email3`, `email2`, `email1`) VALUES
(1, 'Pajak', '2', 'davasvlasvnkNVLAV  SFSAFASFASKLDskfsfaslfal ddvdsgdsgdsbdsbdsbdvdsvsd ddsgds                                            ', '2017-11-17', 'rudy_s@match-advertising.com', '1', NULL, NULL, NULL),
(2, '', '6', '                                            ', '2017-11-20', '', '', NULL, NULL, NULL),
(3, 'test', '2', '                                   ok         ', '2017-11-16', 'ok', '2', NULL, NULL, NULL),
(4, '2', '1', '                                2            ', '2017-11-28', '2', '2', NULL, NULL, NULL),
(5, '', '', '                                            ', '1970-01-01', '', '', NULL, NULL, NULL),
(6, '', '', '                                            ', '1970-01-01', '', '', NULL, NULL, NULL),
(7, '', '', '                                            ', '1970-01-01', '', '', NULL, NULL, NULL),
(8, '', '', '                                            ', '1970-01-01', '', '', NULL, NULL, NULL),
(9, '', '', '                                            ', '1970-01-01', '', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `schedule`
--

CREATE TABLE `schedule` (
  `SCH_ID` int(11) NOT NULL,
  `USR_ID` int(11) DEFAULT NULL,
  `SCH_TITLE` char(30) DEFAULT NULL,
  `SCH_DATE` date DEFAULT NULL,
  `SCH_TIME` time DEFAULT NULL,
  `SCH_INFO` varchar(1024) DEFAULT NULL,
  `SCH_LOC` char(150) DEFAULT NULL,
  `SCH_STS` char(10) DEFAULT NULL,
  `SCH_NOTULEN` varchar(6000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `schedule`
--

INSERT INTO `schedule` (`SCH_ID`, `USR_ID`, `SCH_TITLE`, `SCH_DATE`, `SCH_TIME`, `SCH_INFO`, `SCH_LOC`, `SCH_STS`, `SCH_NOTULEN`) VALUES
(19, 11, 'coba', '2017-11-28', '09:57:00', 'test.. oke', 'R. Meeting', '1', NULL),
(20, 11, 'coba sistem', '2017-11-28', '10:07:00', 'oke system', 'r. meeting', '1', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_group`
--

CREATE TABLE `user_group` (
  `USG_ID` int(11) NOT NULL,
  `USG_NAME` char(100) DEFAULT NULL,
  `USG_DTSTS` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_group`
--

INSERT INTO `user_group` (`USG_ID`, `USG_NAME`, `USG_DTSTS`) VALUES
(1, 'Administrator', '1'),
(2, 'Team Tes', '0'),
(3, 'Team Marketing', '1'),
(4, 'Team Finance', '1'),
(5, 'Team IT', '1'),
(9, 'Team GA', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_ms`
--

CREATE TABLE `user_ms` (
  `USR_ID` int(11) NOT NULL,
  `USG_ID` int(11) NOT NULL,
  `KAR_ID` int(11) NOT NULL,
  `USR_ACCESS` char(10) DEFAULT NULL,
  `USR_DTSTS` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_ms`
--

INSERT INTO `user_ms` (`USR_ID`, `USG_ID`, `KAR_ID`, `USR_ACCESS`, `USR_DTSTS`) VALUES
(4, 1, 71, '0', '1'),
(5, 9, 76, '1', '1'),
(9, 3, 79, '2', '1'),
(10, 4, 85, '2', '1'),
(11, 5, 80, '2', '1'),
(12, 1, 70, '0', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dept_schedule`
--
ALTER TABLE `dept_schedule`
  ADD PRIMARY KEY (`DEPT_ID`,`SCH_ID`),
  ADD KEY `DEPT_ID` (`DEPT_ID`,`SCH_ID`),
  ADD KEY `SCH_ID` (`SCH_ID`);

--
-- Indexes for table `jenis_reminder`
--
ALTER TABLE `jenis_reminder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member_schedule`
--
ALTER TABLE `member_schedule`
  ADD PRIMARY KEY (`SCH_ID`,`KRY_ID`),
  ADD KEY `SCH_ID` (`SCH_ID`),
  ADD KEY `KRY_ID` (`KRY_ID`);

--
-- Indexes for table `reminder`
--
ALTER TABLE `reminder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`SCH_ID`),
  ADD KEY `USR_ID` (`USR_ID`);

--
-- Indexes for table `user_group`
--
ALTER TABLE `user_group`
  ADD PRIMARY KEY (`USG_ID`);

--
-- Indexes for table `user_ms`
--
ALTER TABLE `user_ms`
  ADD PRIMARY KEY (`USR_ID`),
  ADD KEY `USG_ID` (`USG_ID`),
  ADD KEY `KAR_ID` (`KAR_ID`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jenis_reminder`
--
ALTER TABLE `jenis_reminder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reminder`
--
ALTER TABLE `reminder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `SCH_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_group`
--
ALTER TABLE `user_group`
  MODIFY `USG_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_ms`
--
ALTER TABLE `user_ms`
  MODIFY `USR_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `dept_schedule`
--
ALTER TABLE `dept_schedule`
  ADD CONSTRAINT `dept_schedule_ibfk_1` FOREIGN KEY (`SCH_ID`) REFERENCES `schedule` (`SCH_ID`);

--
-- Ketidakleluasaan untuk tabel `member_schedule`
--
ALTER TABLE `member_schedule`
  ADD CONSTRAINT `member_schedule_ibfk_1` FOREIGN KEY (`SCH_ID`) REFERENCES `schedule` (`SCH_ID`);

--
-- Ketidakleluasaan untuk tabel `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`USR_ID`) REFERENCES `user_ms` (`USR_ID`);

--
-- Ketidakleluasaan untuk tabel `user_ms`
--
ALTER TABLE `user_ms`
  ADD CONSTRAINT `user_ms_ibfk_1` FOREIGN KEY (`USG_ID`) REFERENCES `user_group` (`USG_ID`),
  ADD CONSTRAINT `user_ms_ibfk_2` FOREIGN KEY (`KAR_ID`) REFERENCES `karyawan` (`id_karyawan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
